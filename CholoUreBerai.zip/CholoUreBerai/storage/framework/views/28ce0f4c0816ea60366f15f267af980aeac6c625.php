<?php $__env->startSection('content'); ?>
    <div class="container">
        <h1>About Us</h1>
        <p class="lead text-muted">
            This site is specially developed for the bloggers who like and love to write and read blogs. Anyone can write blogs on any topic.
            Feel free to share anything.
            <footer class="blockquote-footer">Made with love by <cite title="Source Title">Cholo Ure Berai</cite></footer>
        </p>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>